def printline():
    return 'hello'